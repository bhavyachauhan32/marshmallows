package helper;

public interface Constants {

    String TAG = "tag";
    String CityAPI = "http://virtualrj.epizy.com/virtualrj/cityapi.php";
    String PlacesAPI = "http://virtualrj.epizy.com/virtualrj/placesapi.php";
}
